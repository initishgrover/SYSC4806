package org.example;

import java.util.ArrayList;
import java.util.List;

public class AddressBook {
    private List<BuddyInfo> buddies;
    public AddressBook(){
        buddies = new ArrayList<>();
    }

    public void addBuddy(BuddyInfo buddy){
        buddies.add(buddy);
    }

    public void removeBuddy(BuddyInfo buddy){
        buddies.remove(buddy);
    }
    public List<BuddyInfo> getBuddies(){
        return buddies;
    }

    public static void main(String[] args) {
        AddressBook addressBook = new AddressBook();
        BuddyInfo buddy1 = new BuddyInfo("Nitish", "11223344");
        BuddyInfo buddy2 = new BuddyInfo("chang", "55667788");

        addressBook.addBuddy(buddy1);
        addressBook.addBuddy(buddy2);

        //addressBook.removeBuddy(buddy1);

        System.out.println(addressBook.getBuddies());
    }
}

