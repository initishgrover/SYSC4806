package org.example;

public class BuddyInfo {
    private String name;
    private String phoneNumber;

    public BuddyInfo(String name, String phoneNumber){
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public String getName(){
        return name;
    }
    public String getPhoneNumber(){
        return phoneNumber;
    }

    @Override
    public String toString(){
        return name + "-" + phoneNumber;
    }
}
